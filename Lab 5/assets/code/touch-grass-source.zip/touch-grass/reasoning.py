"""Structured detector evidence and rejection-only checks of Qwen's report."""
from collections import Counter
from decimal import Decimal, ROUND_HALF_UP
import json
import math
from pathlib import Path
import time

from core import validate_report, write_json

PROMPT_VERSION = 'counted-evidence-v3'


def make_evidence(slots, interval_seconds, simulated=False):
    if not slots:
        raise ValueError('No sampling slots to analyze.')
    if type(interval_seconds) not in (int, float) or not math.isfinite(interval_seconds) or interval_seconds <= 0:
        raise ValueError('Sampling interval must be positive and finite.')
    counts = Counter(row['state'] for row in slots)
    if counts.keys() - {'present', 'absent', 'unknown'}:
        raise ValueError('Unexpected detector state.')
    # These are observation counts, not calculated desk minutes or scores.
    return {'present_samples': counts['present'], 'absent_samples': counts['absent'],
            'unknown_samples': counts['unknown'], 'total_samples': len(slots),
            'seconds_per_sample': interval_seconds, 'is_simulation': bool(simulated)}


def report_schema(evidence):
    count = {'type': 'integer', 'minimum': 0, 'maximum': evidence['total_samples']}
    properties = {key: dict(count) for key in ('present_samples', 'absent_samples', 'unknown_samples')}
    properties.update({
        'is_simulation': {'type': 'boolean'},
        'estimated_desk_minutes': {'type': 'number', 'minimum': 0},
        'score': {'type': 'integer', 'minimum': 0, 'maximum': 100},
        'summary': {'type': 'string'}, 'uncertainty': {'type': 'string'},
    })
    return {'type': 'object', 'properties': properties, 'required': list(properties),
            'additionalProperties': False}


def make_prompt(evidence):
    context = ('This is a SIMULATED day made from a real 15-minute camera recording. '
               'The sampling interval below belongs to the simulated day, not the real recording. '
               'Start summary with "Simulated day:" and start uncertainty with "Simulation:".') if evidence['is_simulation'] else (
               'This is a real sampled recording. Do not claim it covers a full day unless the evidence supports that.')
    return f'''You are Qwen, generating a Touch grass report from detector observations.
{context}

AUTHORITATIVE INPUT
{json.dumps(evidence, indent=2)}
These counts already describe every slot. Copy the three sample counts and is_simulation exactly into your output. Do not recount a sequence or infer extra observations.

YOU must calculate the two output numbers:
estimated_desk_minutes = present_samples * seconds_per_sample / 60.
If estimated_desk_minutes >= 480, score MUST be 100.
Otherwise, score = estimated_desk_minutes / 4.8, rounded to the nearest integer with halves rounded up.
Never output a score greater than 100. Never include unknown_samples in desk time.

Return only one JSON object matching the schema.
summary: one short sentence giving your calculated time and score, with gentle teasing.
uncertainty: one short sentence. Include the exact phrase "unknown slots: N", replacing N with unknown_samples. Mention possible missed detections and that presence does not prove computer use. Zero unknown slots means no missing observations; it does NOT mean perfect detection.
Do not invent events, identities or additional people.'''


def validate_reasoned_report(value, evidence):
    """Accept or raise. Never supply, clamp, round, or replace output fields."""
    maximum = evidence['total_samples'] * evidence['seconds_per_sample'] / 60
    validate_report(value, max_minutes=maximum)
    for key in ('present_samples', 'absent_samples', 'unknown_samples'):
        if type(value.get(key)) is not int or value[key] != evidence[key]:
            raise ValueError(f'{key} does not match the supplied observations. Copy the input count exactly.')
    if type(value.get('is_simulation')) is not bool or value['is_simulation'] != evidence['is_simulation']:
        raise ValueError('is_simulation must match the input recording type.')
    minutes = Decimal(str(value['estimated_desk_minutes']))
    # Check the arithmetic relationship, without returning a replacement answer.
    if abs(minutes * 60 - Decimal(evidence['present_samples']) * Decimal(str(evidence['seconds_per_sample']))) > Decimal('0.001'):
        raise ValueError('estimated_desk_minutes fails present_samples * seconds_per_sample / 60. Recalculate it yourself.')
    if minutes >= 480:
        if value['score'] != 100:
            raise ValueError('Apply the score cap: at least 480 minutes requires score 100.')
    elif Decimal(value['score']) != (minutes / Decimal('4.8')).quantize(Decimal('1'), rounding=ROUND_HALF_UP):
        raise ValueError('score fails the nearest-integer rule for estimated_desk_minutes / 4.8. Recalculate it yourself.')
    if evidence['is_simulation']:
        if not value['summary'].lower().startswith('simulated day:') or not value['uncertainty'].lower().startswith('simulation:'):
            raise ValueError('Label the summary "Simulated day:" and the uncertainty "Simulation:".')
    if f"unknown slots: {evidence['unknown_samples']}" not in value['uncertainty'].lower():
        raise ValueError('State the exact unknown-slot count using "unknown slots: N".')
    return value


def request_report(evidence, model, output_dir, generate, max_attempts=3, progress=None):
    """Request bounded retries; retain every answer, including rejected attempts.

    generate takes an Ollama request and returns its JSON response. Numbers in an
    accepted report remain exactly those in that model response.
    """
    if not 1 <= max_attempts <= 3:
        raise ValueError('Use one to three model attempts.')
    out = Path(output_dir)
    base_prompt = make_prompt(evidence)
    write_json(out / 'evidence.json', evidence)
    schema = report_schema(evidence)
    attempts = []
    error = None
    for index in range(1, max_attempts + 1):
        prompt = base_prompt
        if error:
            prompt += '\n\nThe previous answer was rejected: ' + error + '\nStart from the authoritative input and calculate a fresh answer.'
        folder = out / f'attempt-{index}'
        folder.mkdir(parents=True, exist_ok=False)
        (folder / 'prompt.txt').write_text(prompt, encoding='utf-8')
        # Keep reasoning enabled for the arithmetic; bound both tokens and attempts.
        request = {'model': model, 'prompt': prompt, 'format': schema,
                   'think': True, 'stream': False,
                   'options': {'num_ctx': 4096, 'num_predict': 2048, 'temperature': 0},
                   'keep_alive': '5m'}
        write_json(folder / 'request.json', request)
        if progress:
            progress(index)
        began = time.monotonic()
        payload = generate(request)
        seconds = round(time.monotonic() - began, 2)
        write_json(folder / 'ollama-response.json', payload)
        raw = payload.get('response', '')
        (folder / 'raw-response.txt').write_text(raw, encoding='utf-8')
        answer = None
        try:
            if not raw.strip():
                raise ValueError('Qwen returned no final answer.')
            answer = validate_reasoned_report(json.loads(raw), evidence)
            error = None
        except (ValueError, TypeError) as exc:
            error = str(exc)
        attempts.append({'attempt': index, 'seconds': seconds, 'valid': error is None, 'error': error})
        write_json(folder / 'validation.json', attempts[-1])
        if error is None:
            break
    # Compatibility copies contain the selected attempt unchanged. Older jobs stay intact.
    for name in ('prompt.txt', 'ollama-response.json', 'raw-response.txt'):
        (out / name).write_bytes((folder / name).read_bytes())
    result = {'model': model, 'request_seconds': round(sum(a['seconds'] for a in attempts), 2),
              'raw': raw, 'prompt_version': PROMPT_VERSION, 'evidence': evidence,
              'attempts': attempts, 'valid': error is None,
              'validation': 'Counts, arithmetic, bounds and simulation labels checked; model numbers are never replaced.'}
    if error:
        result['error'] = error
    else:
        result['answer'] = answer
    return result
