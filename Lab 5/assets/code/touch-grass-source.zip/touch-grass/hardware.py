# SPDX-FileCopyrightText: 2021 ladyada for Adafruit Industries
# SPDX-License-Identifier: MIT
# Display initialization adapted from the installed Adafruit Mini PiTFT example.
"""Mini PiTFT adapter. Reuses the current screen service's verified pin configuration.

Display setup follows /home/pi/screen_boot_script.py, originally the Adafruit MIT example.
No wiring changes are required. Run in /home/pi/venv, where the existing drivers are installed.
"""
import argparse
import json
from pathlib import Path
import signal
import threading
import time
import urllib.request
import urllib.error

from core import PressEdge, now, write_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--store', required=True)
    parser.add_argument('--url', default='http://127.0.0.1:8080')
    parser.add_argument('--display-url', default='192.168.1.39:8080')
    args = parser.parse_args()
    store = Path(args.store)
    token = (store / 'control-token').read_text().strip()
    import board
    import digitalio
    from PIL import Image, ImageDraw, ImageFont
    from adafruit_rgb_display import st7789

    stopped = threading.Event()
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, lambda *_: stopped.set())
    pins = []
    spi = None
    try:
        cs, dc = digitalio.DigitalInOut(board.D5), digitalio.DigitalInOut(board.D25)
        pins.extend([cs, dc])
        spi = board.SPI()
        display = st7789.ST7789(spi, cs=cs, dc=dc, rst=None, baudrate=64000000,
                               width=135, height=240, x_offset=53, y_offset=40)
        light = digitalio.DigitalInOut(board.D22)
        light.switch_to_output(value=True)
        a, b = digitalio.DigitalInOut(board.D23), digitalio.DigitalInOut(board.D24)
        pins.extend([light, a, b])
        a.switch_to_input(pull=digitalio.Pull.UP)
        b.switch_to_input(pull=digitalio.Pull.UP)
        font = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
        large = ImageFont.truetype(font, 23)
        small = ImageFont.truetype(font, 14)
        medium = ImageFont.truetype(font, 17)
        edge = PressEdge()
        last_poll = 0
        press_count = 0
        state = {}
        notice = ''
        notice_until = 0
        print('Mini PiTFT ready. Either button starts one batch.', flush=True)
        while not stopped.is_set():
            stamp = time.monotonic()
            if edge.update(not a.value or not b.value, stamp):
                press_count += 1
                try:
                    request = urllib.request.Request(args.url + '/api/process', data=b'{}',
                              headers={'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json',
                                       'X-Input-Source': 'mini-pitft'})
                    with urllib.request.urlopen(request, timeout=20) as reply:
                        notice = json.load(reply)['message']
                    print(json.dumps({'button_press': press_count, 'message': notice}), flush=True)
                except Exception as exc:
                    notice = 'Cannot reach service.'
                    print(json.dumps({'button_error': str(exc)}), flush=True)
                notice_until = time.monotonic() + 4
                last_poll = 0
            if stamp - last_poll >= 1:
                last_poll = stamp
                try:
                    with urllib.request.urlopen(args.url + '/api/state', timeout=3) as reply:
                        state = json.load(reply)
                    connected = True
                except Exception:
                    connected = False
                status = state.get('status', 'offline') if connected else 'offline'
                names = {'scheduled': 'Starts at 8:00', 'armed': 'Demo armed', 'ready': 'Press to analyze', 'collecting': 'Collecting',
                         'processing': 'Processing...', 'complete': 'Report ready',
                         'failed': 'Check webpage', 'needs_review': 'Review report', 'offline': 'Service offline'}
                frame = Image.new('RGB', (240, 135), '#e8f3ff')
                draw = ImageDraw.Draw(frame)
                draw.text((8, 5), 'Express demo' if state.get('kind') == 'express_demo' else 'Touch grass', font=large, fill='#203b2a')
                draw.text((8, 37), names.get(status, status), font=medium, fill='#203b2a')
                if time.monotonic() < notice_until:
                    line = notice[:29]
                elif state.get('kind') == 'express_demo' and status == 'armed':
                    line = 'Press to capture 15 min'
                elif state.get('kind') == 'express_demo' and status == 'collecting':
                    remaining = state.get('remaining_seconds') or 0
                    line = f'{remaining // 60:02d}:{remaining % 60:02d} left | {state.get("sample_count", 0)} photos'
                elif status == 'processing':
                    progress = state.get('progress') or {}
                    line = 'Qwen is thinking' if progress.get('stage') == 'reasoning' else 'Reading photos'
                elif status == 'complete' and state.get('report', {}).get('valid'):
                    line = ('Sim score: ' if state.get('kind') == 'express_demo' else 'Score: ') + str(state['report']['answer']['score']) + '/100'
                else:
                    line = str(state.get('sample_count', 0)) + ' photos | press to process'
                draw.text((8, 65), line, font=small, fill='#52764e')
                draw.line((8, 91, 232, 91), fill='#b8cab4')
                draw.text((8, 100), args.display_url, font=small, fill='#203b2a')
                display.image(frame, 90)
                write_json(store / 'hardware-status.json', {'connected': connected, 'display': 'active',
                           'updated_at': now().isoformat(), 'button_presses': press_count})
            stopped.wait(0.02)
    finally:
        for pin in reversed(pins):
            try:
                pin.deinit()
            except Exception:
                pass
        if spi is not None:
            spi.deinit()


if __name__ == '__main__':
    main()
