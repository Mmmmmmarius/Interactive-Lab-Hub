"""Local operator controls; no token is printed or embedded in a command line."""
import argparse
import json
from pathlib import Path
from urllib.request import Request, urlopen


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['demo', 'daily', 'press', 'status'])
    parser.add_argument('--config', default=str(Path(__file__).with_name('config.json')))
    args = parser.parse_args()
    config = json.loads(Path(args.config).read_text())
    url = 'http://127.0.0.1:' + str(config.get('port', 8080))
    if args.action == 'status':
        with urlopen(url + '/api/state', timeout=20) as reply:
            state = json.load(reply)
        print(json.dumps({key: state.get(key) for key in ['batch_id', 'kind', 'status', 'sample_count', 'remaining_seconds', 'report']}, indent=2))
        return
    token = (Path(config['store']) / 'control-token').read_text().strip()
    routes = {'demo': '/api/demo/arm', 'daily': '/api/demo/daily', 'press': '/api/process'}
    request = Request(url + routes[args.action], data=b'{}', headers={'Authorization': 'Bearer ' + token})
    with urlopen(request, timeout=20) as reply:
        print(reply.read().decode())


if __name__ == '__main__':
    main()
