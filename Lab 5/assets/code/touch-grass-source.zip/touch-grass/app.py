"""Local-only camera scheduler, physical-button job queue and read-only LAN UI."""
import argparse
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hmac
import json
import math
import mimetypes
import os
from pathlib import Path
import re
import secrets
import signal
import subprocess
import sys
import threading
import time
from urllib.parse import parse_qs, urlsplit

from core import ZONE, day_key, day_start, next_start, now, read_json, slot, write_json

HERE = Path(__file__).resolve().parent


class Controller:
    def __init__(self, config_path):
        self.config_path = Path(config_path).resolve()
        self.config = read_json(self.config_path)
        self.store = Path(self.config['store'])
        self.store.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.stop = threading.Event()
        self.busy = False
        self.last_button = None
        token_file = self.store / 'control-token'
        if not token_file.exists():
            token_file.write_text(secrets.token_urlsafe(32), encoding='utf-8')
            token_file.chmod(0o600)
        self.token = token_file.read_text(encoding='utf-8').strip()
        # An interrupted job remains visible; it must not silently restart or resume capture.
        for meta_path in [*(self.store / 'days').glob('*/day.json'), *(self.store / 'demos').glob('*/day.json')]:
            meta = read_json(meta_path)
            if meta.get('status') == 'processing':
                meta.update(status='failed', error='Processing was interrupted. Press the Pi button to retry.')
                write_json(meta_path, meta)

    def path(self, day):
        if re.fullmatch(r'express-\d{8}-\d{6}-\d{6}', day):
            return self.store / 'demos' / day
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', day):
            raise ValueError('Invalid date')
        datetime.fromisoformat(day)
        return self.store / 'days' / day

    def load(self, day):
        return read_json(self.path(day) / 'day.json')

    def save(self, meta):
        write_json(self.path(meta.get('batch_id', meta['date'])) / 'day.json', meta)

    def active_demo(self, moment=None):
        pointer = read_json(self.store / 'active-demo.json', {})
        batch = pointer.get('batch_id')
        meta = self.load(batch) if batch else None
        if meta and (moment or now()) < datetime.fromisoformat(meta['resume_daily_at']):
            return meta
        if meta and meta['status'] in ('armed', 'collecting', 'ready'):
            meta['status'] = 'expired'
            self.save(meta)
        return None

    def arm_demo(self):
        with self.lock:
            if self.busy:
                return {'message': 'Wait for the current report before arming a demo.'}
            active = self.active_demo()
            if active and active['status'] in ('armed', 'collecting', 'ready', 'processing'):
                return {'message': 'An express demo is already active.', 'batch_id': active['batch_id']}
            stamp = now()
            batch = 'express-' + stamp.strftime('%Y%m%d-%H%M%S-%f')
            start = day_start(stamp.date().isoformat())
            meta = {'batch_id': batch, 'date': stamp.date().isoformat(), 'kind': 'express_demo',
                    'status': 'armed', 'armed_at': stamp.isoformat(), 'window_start': None, 'window_end': None,
                    'collection_started_at': None, 'duration_seconds': 900, 'interval_seconds': 30,
                    'samples': [], 'last_slot': -1, 'progress': None, 'report': None,
                    'resume_daily_at': next_start(stamp, stamp.date().isoformat()).isoformat(),
                    'simulation': {'label': 'Simulated day 08:00-20:00; captured during a real 15-minute demo',
                                   'start': start.isoformat(), 'end': (start + timedelta(hours=12)).isoformat(),
                                   'interval_seconds': 1440}}
            self.save(meta)
            write_json(self.store / 'active-demo.json', {'batch_id': batch})
            return {'message': 'Express demo armed. Press a Pi button to begin 15 minutes of capture.', 'batch_id': batch}

    def return_to_daily(self):
        with self.lock:
            if self.busy:
                return {'message': 'Wait for processing to finish before leaving demo mode.'}
            meta = self.active_demo()
            if meta and meta['status'] in ('armed', 'collecting', 'ready'):
                meta.update(status='cancelled', cancelled_at=now().isoformat())
                self.save(meta)
            write_json(self.store / 'active-demo.json', {})
            return {'message': 'Daily mode restored. Demo records are kept.'}

    def new_day(self, day, kind='daytime'):
        return {'date': day, 'kind': kind, 'status': 'collecting',
                'window_start': day_start(day).isoformat(), 'window_end': None,
                'collection_started_at': now().isoformat(), 'interval_seconds': 300,
                'samples': [], 'last_slot': -1, 'progress': None, 'report': None}

    def take_sample(self, meta):
        began = now()
        filename = 'photos/' + began.strftime('%H%M%S-%f') + '.jpg'
        output = self.path(meta.get('batch_id', meta['date'])) / filename
        try:
            result = subprocess.run([sys.executable, str(HERE / 'worker.py'), 'capture', '--output', str(output)],
                                    capture_output=True, text=True, timeout=15)
            if result.returncode:
                raise RuntimeError(result.stderr[-1200:] or 'Camera capture failed')
            capture = json.loads(result.stdout.strip().splitlines()[-1])
            sample = {'captured_at': capture['captured_at'], 'file': filename}
            meta.pop('capture_error', None)
        except Exception as exc:
            sample = {'captured_at': began.isoformat(), 'file': None, 'error': str(exc)}
            meta['capture_error'] = 'A photo could not be captured. Check the camera and close other camera demos.'
        meta['samples'].append(sample)
        self.save(meta)

    def tick(self, moment=None):
        moment = moment or now()
        with self.lock:
            demo = self.active_demo(moment)
            if demo:
                self.tick_demo(demo, moment)
                return
        if moment < day_start(self.config['first_day']):
            return
        day = day_key(moment)
        with self.lock:
            meta = self.load(day) or self.new_day(day)
            if meta['status'] != 'collecting':
                return
            current = slot(moment, day_start(day), 300)
            if current > meta['last_slot']:
                meta['last_slot'] = current  # No historical catch-up photographs.
                self.save(meta)
                self.take_sample(meta)

    def tick_demo(self, meta, moment):
        if meta['status'] != 'collecting':
            return
        if moment >= datetime.fromisoformat(meta['window_end']):
            meta['status'] = 'ready'
            self.save(meta)
            return
        current = slot(moment, datetime.fromisoformat(meta['window_start']), meta['interval_seconds'])
        if current > meta['last_slot']:
            meta['last_slot'] = current
            self.save(meta)
            self.take_sample(meta)

    def schedule(self):
        while not self.stop.is_set():
            try:
                self.tick()
            except Exception as exc:
                print(json.dumps({'scheduler_error': str(exc)}), flush=True)
            self.stop.wait(1)

    def prepare_test(self):
        day = day_key(now())
        if self.load(day):
            raise ValueError('A batch already exists for today. It will not be overwritten.')
        meta = self.new_day(day, 'setup_test')
        meta.update(window_start=now().isoformat(), interval_seconds=2)
        for index in range(3):
            self.take_sample(meta)
            if index < 2:
                time.sleep(2)
        # This short test ends at its last sample, rather than running until the later button press.
        end = datetime.fromisoformat(meta['samples'][-1]['captured_at']) + timedelta(seconds=2)
        meta.update(status='ready', window_end=end.isoformat())
        self.save(meta)
        print(json.dumps({'prepared_test': day, 'samples': len(meta['samples'])}), flush=True)

    def process_button(self, source='software-check'):
        with self.lock:
            moment = now()
            demo = self.active_demo(moment)
            if demo and demo['status'] == 'collecting' and moment >= datetime.fromisoformat(demo['window_end']):
                demo['status'] = 'ready'
                self.save(demo)
            day = demo['batch_id'] if demo else day_key(moment)
            meta = demo or self.load(day)
            self.last_button = {'at': now().isoformat(), 'result': 'received', 'source': source}
            self.last_button['batch_id'] = day
            if self.busy or (meta and meta['status'] == 'processing'):
                message = 'Already processing this batch.'
            elif demo and meta['status'] == 'armed':
                meta.update(status='collecting', window_start=moment.isoformat(),
                            collection_started_at=moment.isoformat(),
                            window_end=(moment + timedelta(seconds=meta['duration_seconds'])).isoformat())
                self.save(meta)
                message = '15-minute capture started.'
            elif demo and meta['status'] == 'collecting':
                message = 'Still capturing. Press after the 15-minute timer ends.'
            elif not meta or not any(s.get('file') for s in meta['samples']):
                message = 'No photos yet. Collection starts at 8:00.'
            elif meta['status'] == 'complete' and meta.get('kind') != 'setup_test':
                message = 'This batch is complete. Next collection starts at 8:00.'
            else:
                meta['window_end'] = meta.get('window_end') or now().isoformat()
                meta.update(status='processing', progress={'stage': 'starting', 'done': 0, 'total': len(meta['samples'])})
                meta.pop('error', None)
                job_id = now().strftime('%H%M%S-%f')
                meta['job'] = job_id
                self.save(meta)
                self.busy = True
                threading.Thread(target=self.run_job, args=(day, job_id), daemon=True).start()
                message = 'Processing started.'
            self.last_button['result'] = message
            with (self.store / 'button-events.jsonl').open('a', encoding='utf-8') as stream:
                stream.write(json.dumps(self.last_button) + '\n')
            return {'message': message}

    def run_job(self, day, job_id):
        folder = self.path(day)
        out = folder / 'jobs' / job_id
        out.mkdir(parents=True, exist_ok=True)
        try:
            cmd = [sys.executable, str(HERE / 'worker.py'), 'analyze', '--manifest', str(folder / 'day.json'),
                   '--config', str(self.config_path), '--output', str(out)]
            with (out / 'console.txt').open('w', encoding='utf-8') as logfile:
                child = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                for line in child.stdout:
                    logfile.write(line)
                    logfile.flush()
                    try:
                        event = json.loads(line)
                        if 'stage' in event:
                            with self.lock:
                                meta = self.load(day)
                                meta['progress'] = event
                                self.save(meta)
                    except (ValueError, TypeError):
                        pass
                code = child.wait()
            if code:
                raise RuntimeError('Analysis failed. Check the saved run log, then press the Pi button to retry.')
            report = read_json(out / 'report.json')
            with self.lock:
                meta = self.load(day)
                meta.update(status='complete' if report['valid'] else 'needs_review', report=report)
                if not report['valid']:
                    meta['error'] = report['error']
                self.save(meta)
        except Exception as exc:
            with self.lock:
                meta = self.load(day)
                meta.update(status='failed', error=str(exc))
                self.save(meta)
        finally:
            with self.lock:
                self.busy = False

    def state(self, day=None):
        with self.lock:
            active = self.active_demo()
            selected = day or (active['batch_id'] if active else day_key(now()))
            meta = self.load(selected)
            if meta is None and selected.startswith('express-'):
                raise ValueError('Unknown demo')
            result = meta.copy() if meta else {'date': selected, 'kind': 'daytime', 'status': 'scheduled', 'samples': []}
            result['batch_id'] = selected
            result['remaining_seconds'] = max(0, math.ceil((datetime.fromisoformat(meta['window_end']) - now()).total_seconds())) if meta and meta['kind'] == 'express_demo' and meta.get('window_end') else None
            result['sample_count'] = sum(bool(s.get('file')) for s in result['samples'])
            result['missing_count'] = sum(not s.get('file') for s in result['samples'])
            result['next_start'] = next_start(now(), self.config['first_day']).isoformat()
            result['first_day'] = self.config['first_day']
            result['timezone'] = 'America/New_York'
            result['last_button'] = self.last_button
            result['hardware'] = read_json(self.store / 'hardware-status.json', {})
            result['days'] = sorted([p.parent.name for p in (self.store / 'days').glob('*/day.json')], reverse=True)
            records = [*(self.store / 'days').glob('*/day.json'), *(self.store / 'demos').glob('*/day.json')]
            result['batches'] = []
            for path in sorted(records, key=lambda p: p.parent.name, reverse=True):
                record = read_json(path)
                result['batches'].append({'id': record.get('batch_id', record['date']),
                                          'date': record['date'], 'kind': record['kind']})
            if meta and meta.get('job'):
                result['detections'] = read_json(self.path(selected) / 'jobs' / meta['job'] / 'detections.json', [])
                result['sampling_slots'] = read_json(self.path(selected) / 'jobs' / meta['job'] / 'sampling-slots.json', [])
            else:
                result['detections'] = []
                result['sampling_slots'] = []
            result['local_time'] = now().isoformat()
            return result


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        if args and str(args[0]).startswith('POST'):
            super().log_message(fmt, *args)

    def send(self, data, mime='application/json', code=200):
        payload = json.dumps(data, ensure_ascii=False).encode() if mime == 'application/json' else data
        self.send_response(code)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        target = urlsplit(self.path)
        try:
            if target.path == '/api/state':
                day = parse_qs(target.query).get('day', [None])[0]
                self.send(self.server.controller.state(day))
                return
            if target.path.startswith('/media/'):
                parts = target.path.split('/')
                if len(parts) != 4 or not re.fullmatch(r'\d{6}-\d{6}\.jpg', parts[3]):
                    raise ValueError('Invalid photo')
                file = self.server.controller.path(parts[2]) / 'photos' / parts[3]
            else:
                allowed = {'/': 'index.html', '/style.css': 'style.css', '/app.js': 'app.js'}
                if target.path not in allowed:
                    raise FileNotFoundError()
                file = HERE / 'web' / allowed[target.path]
            mime = mimetypes.guess_type(str(file))[0] or 'application/octet-stream'
            if mime.startswith('text/') or mime == 'application/javascript':
                mime += '; charset=utf-8'
            self.send(file.read_bytes(), mime)
        except (ValueError, FileNotFoundError):
            self.send({'error': 'Not found'}, code=404)

    def do_POST(self):
        if self.path not in ('/api/process', '/api/demo/arm', '/api/demo/daily'):
            self.send({'error': 'Not found'}, code=404)
            return
        provided = self.headers.get('Authorization', '').removeprefix('Bearer ')
        if not hmac.compare_digest(provided, self.server.controller.token):
            self.send({'error': 'Use the button on the Pi to start processing.'}, code=403)
            return
        source = 'physical-button' if self.headers.get('X-Input-Source') == 'mini-pitft' else 'software-check'
        if self.path == '/api/demo/arm':
            result = self.server.controller.arm_demo()
        elif self.path == '/api/demo/daily':
            result = self.server.controller.return_to_daily()
        else:
            result = self.server.controller.process_button(source=source)
        self.send(result)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=str(HERE / 'config.json'))
    parser.add_argument('--prepare-test', action='store_true')
    args = parser.parse_args()
    control = Controller(args.config)
    if args.prepare_test:
        control.prepare_test()
        return
    server = ThreadingHTTPServer((control.config.get('host', '0.0.0.0'), control.config.get('port', 8080)), Handler)
    server.controller = control
    threading.Thread(target=control.schedule, daemon=True).start()

    def stop(signum, frame):
        control.stop.set()
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    print(json.dumps({'listening': server.server_address, 'first_day': control.config['first_day']}), flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
