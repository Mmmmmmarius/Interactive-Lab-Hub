// Regression checks for presentation boundaries, using no browser or Pi changes.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=['grass-bro.js','view-state.js'].map(name=>fs.readFileSync(path.join(__dirname,'ui',name),'utf8')).join('\n');
const {GrassView,GrassBro}=vm.runInNewContext(source+';({GrassView,GrassBro});');
const complete=score=>({batch_id:'demo-a',job:'job-a',status:'complete',report:{valid:true,answer:{score,estimated_desk_minutes:552}}});
for(const [score,id] of [[0,'chill'],[24,'chill'],[25,'locked'],[49,'locked'],[50,'nudge'],[74,'nudge'],[75,'deadass'],[99,'deadass'],[100,'cooked']])assert.equal(GrassView.character(complete(score)).id,id);
for(const score of [-1,101,NaN,Infinity,'100',null,0.5])assert.equal(GrassView.answer(complete(score)),null);
for(const status of ['armed','scheduled','collecting','ready','processing','failed','needs_review'])assert.equal(GrassView.answer({...complete(100),status}),null,'Old report must not leak into '+status);
assert.equal(GrassView.answer({...complete(100),report:{valid:false,answer:{score:100,estimated_desk_minutes:552}}}),null);
for(const minutes of [-1,NaN,Infinity,'552']){const state=complete(100);state.report.answer.estimated_desk_minutes=minutes;assert.equal(GrassView.answer(state),null);}
assert.equal(GrassView.character({status:'scheduled'}).id,'waiting');
assert.equal(GrassView.character({status:'collecting'}).id,'collecting');
assert.equal(GrassView.character({status:'ready'}).id,'ready');
assert.equal(GrassView.character({status:'processing'}).id,'processing');
assert.equal(GrassView.character({status:'needs_review'}).id,'error');
assert.equal(GrassView.character(complete(100),true).id,'offline');
assert.equal(GrassView.character({status:'collecting',capture_error:'Camera busy'}).name,'Capture needs attention');
const state=complete(100),before=JSON.stringify(state),model=state.report.answer;
assert.equal(GrassView.answer(state),model,'Return original object, not computed values');
GrassView.character(state);assert.equal(JSON.stringify(state),before,'Presentation does not mutate report');
assert.equal(GrassView.key(state,GrassView.character(state)),GrassView.key({...state,local_time:'later'},GrassView.character(state)),'Polling must not reset the caption');
assert.notEqual(GrassView.key(state,GrassView.character(state)),GrassView.key({...state,batch_id:'demo-b'},GrassView.character(state)),'A new batch resets the caption');
new vm.Script(fs.readFileSync(path.join(__dirname,'web/app.js'),'utf8'));
console.log('PASS: score boundaries, invalid results, stale reports, runtime states, polling identity, unchanged model values and bundle syntax.');
