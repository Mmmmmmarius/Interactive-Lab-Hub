// Approved Grass bro artwork and caption library.
const GrassBro = (() => {


const scoreStates = [
 {id:'chill',range:'0–24',name:'Chillin',quote:"we're chillin.",extra:['no roast today.','looking pretty chill, brother.'],caption:'Relaxed leaves. Not a care in the turf.'},
 {id:'locked',range:'25–49',name:'Locked in',quote:'locked in, huh?',extra:['interesting chair commitment.','the chair has your attention.'],caption:'One eyebrow up. Quietly taking notes.'},
 {id:'nudge',range:'50–74',name:'The nudge',quote:'touch some grass, brother.',extra:["i'm grass. i'm right here.",'the chair can wait.'],caption:'Hands on hips. The hint is no longer subtle.'},
 {id:'deadass',range:'75–99',name:'Disbelief',quote:'are we deadass rn?',extra:["bro. the chair isn't going anywhere.",'outside is still a thing.'],caption:'A long stare. A very long stare.'},
 {id:'cooked',range:'100',name:'Fully cooked',quote:'bro is fully cooked.',extra:['the chair won.','touch some grass, brother. seriously.'],caption:'White flag. Absolutely out of words.'}
];
const runtimeStates = [
 {id:'waiting',name:'Waiting',quote:'ready when you are, brother.',detail:'Press the Mini PiTFT button to start the express demo.'},
 {id:'collecting',name:'Collecting',quote:'gathering the receipts.',detail:'Photos are being saved. Capture progress stays visible.'},
 {id:'ready',name:'Ready to analyze',quote:'the receipts are in.',detail:'Capture finished. Press the Pi button to start analysis.'},
 {id:'processing',name:'Analyzing',quote:'let me cook.',detail:'Reading the saved photos and preparing the report.'},
 {id:'error',name:'Validation failed',quote:"that math ain't mathing.",detail:'The report did not pass validation. Original answer saved.'},
 {id:'offline',name:'Disconnected',quote:'bro? you there?',detail:'Cannot reach the Pi. Check power and the local network.'}
];
const ink='#173a29', green='#71c940', cream='#fffef7';
const path=(d,fill='none',width=5,stroke=ink)=>`<path d="${d}" fill="${fill}" stroke="${stroke}" stroke-width="${width}" stroke-linecap="round" stroke-linejoin="round"/>`;
const ellipse=(cx,cy,rx,ry,fill,stroke='none',sw=0)=>`<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}"/>`;
const circle=(cx,cy,r,fill,stroke='none',sw=0)=>`<circle cx="${cx}" cy="${cy}" r="${r}" fill="${fill}" stroke="${stroke}" stroke-width="${sw}"/>`;
function eyes(kind){
 const pupil=(x,y)=>`<g class="eye-pupil">${ellipse(x,y,5.7,8,ink)}</g>`;
 if(kind==='chill') return path('M78 165q12-14 25 0M137 165q12-14 25 0','none',5)+path('M109 191q15 14 30-2','none',4)+ellipse(75,183,10,5,'#ef8bb2')+ellipse(167,183,10,5,'#ef8bb2');
 if(kind==='deadass') return ellipse(92,162,21,27,cream,ink,4)+ellipse(151,162,21,27,cream,ink,4)+pupil(95,161)+pupil(154,161)+path('M72 124q17-13 35-2M136 126l28 9','none',5)+ellipse(124,202,9,13,ink)+path('M54 134l-9-10M184 127l10-10','none',3);
 if(kind==='cooked') return ellipse(92,172,21,18,cream,ink,4)+ellipse(146,172,21,18,cream,ink,4)+pupil(97,179)+pupil(150,179)+path('M72 163l40 8M127 163l39 8','#a8ca6b',5)+path('M114 204l22 4','none',4)+path('M75 197l15 3M148 198l15 3','none',2.5);
 if(kind==='error') return ellipse(92,162,21,25,cream,ink,4)+ellipse(151,168,21,19,cream,ink,4)+pupil(92,159)+pupil(147,174)+path('M72 127l30 7M136 139l29-12','none',4)+path('M109 202l8-5 9 7 8-5 7 5','none',3.5);
 if(kind==='offline') return ellipse(92,166,20,22,cream,ink,4)+ellipse(151,166,20,22,cream,ink,4)+pupil(84,167)+pupil(143,167)+path('M74 130l28 5M138 135l25-5','none',4)+path('M116 203q8-9 17 0','none',4);
 if(kind==='waiting'||kind==='ready') return ellipse(92,166,19,23,cream,ink,4)+ellipse(150,166,19,23,cream,ink,4)+pupil(95,167)+pupil(153,167)+path('M110 198q15 17 29-2','none',4);
 const py=kind==='processing'?177:173;
 const px=kind==='collecting'?-5:kind==='locked'?5:0;
 return ellipse(92,167,20,23,cream,ink,4)+ellipse(151,167,20,23,cream,ink,4)+pupil(92+px,py)+pupil(151+px,py)+path('M72 160h40M131 160h40','none',4)+path(kind==='locked'?'M75 136l27 3M135 131q15-12 28-3':'M73 139h28M136 139h27','none',4)+path(kind==='nudge'?'M111 200q17 9 31-5':'M113 201h22','none',4);
}
function pet(kind){
 const cooked=kind==='cooked',shock=kind==='deadass',off=kind==='offline';
 const base=cooked?'#a8ca6b':off?'#99bf91':green;
 const body=cooked?'M59 223C38 199 41 167 56 146C64 127 70 105 58 85C87 96 99 114 102 140C101 97 120 62 156 67C178 68 182 87 176 102C169 89 155 88 148 108L142 139C160 117 192 104 209 120C215 125 216 137 209 148C204 135 193 134 189 142C206 170 207 199 190 222Q131 247 59 223Z':shock?'M60 223C43 206 40 176 51 150C56 132 61 112 51 91C76 100 90 117 99 141C87 96 94 59 114 34C130 62 138 89 137 125C153 92 178 79 194 88C201 93 201 103 194 109C187 102 180 103 176 110C180 129 189 142 195 158C207 186 204 209 188 225Q128 246 60 223Z':'M59 224C42 207 39 177 50 150C56 130 61 107 51 83C77 93 92 113 99 141C87 99 93 58 112 32C129 58 140 87 138 124C152 91 172 76 193 78C180 102 184 132 194 153C207 180 204 209 187 225Q128 247 59 224Z';
 let back='',front='';
 if(cooked){back+=path('M78 224Q65 244 40 249M156 228q13 20 39 19','none',7)+path('M24 249q12-11 28 0v8H25Z',base,4)+path('M187 246q16-13 29 1v9h-26Z',base,4);back+=path('M188 185q23 25 42-13','none',6)+path('M223 211V89','none',4);front+=path('M224 91q19-11 39 2l-6 36q-18-10-33 0Z',cream,3)+path('M56 185q-21 25-18 39','none',6)+circle(39,224,8,base,ink,3);}
 else {back+=path('M84 225l-5 28M153 227l7 26','none',7)+path('M57 254q13-12 29-2l3 9H58Z',base,4)+path('M152 254q16-11 31 0l1 8h-31Z',base,4);}
 if(kind==='chill'){back+=path('M53 182q-21 24-29 3M190 183q27 16 34-7','none',6);front+=path('M24 186l-7-4m7 4l-1-9M222 179l9-2m-9 2 3-9','none',3);}
 if(kind==='locked'){back+=path('M54 184q-25 12-15 30M190 184q30-8 22-33','none',6);front+=path('M207 152q-9-6-13 1m14-1 9-6m-9 6 10 2','none',3.5);}
 if(kind==='nudge'){back+=path('M53 176q-29 11-15 29l17-8M191 177q30 0 23 21l-23-6','none',6);front+=path('M181 194l14-3m-14 3 8-8m-8 8 10 4','none',4)+path('M58 197l-10-3','none',3.5);}
 if(shock){back+=path('M51 182q-18 15-26 0l-4-18M193 181q20 13 29-7l3-10','none',6);front+=path('M21 164l-10-6m10 6-1-13m1 13 9-10M225 164l11-8m-11 8 1-14m-1 14-8-10','none',3.5);}
 if(kind==='waiting'){back+=path('M54 183q-16 25-2 38M191 183q18 27 5 37','none',6);front+=circle(53,222,8,base,ink,3)+circle(195,222,8,base,ink,3)+circle(218,54,19,cream,ink,3)+path('M218 43v12l8 4','none',3);}
 if(kind==='collecting'){back+=path('M52 182q-14 34 42 47M191 183q22 28-14 46','none',6);front+=path('M99 211l8-9h34l8 9h27v42H90v-42Z','#234d39',4)+circle(133,231,15,'#d9eeff',cream,3)+circle(133,231,7,ink)+circle(162,220,3,'#ffd65a')+path('M199 67l6-11m4 19 13-1m-21 10 6 10','none',3.5);}
 if(kind==='ready'){back+=path('M54 183q-22 24-5 35M191 182q17 21 32 0','none',6);front+=path('M199 123h57v93h-57Z',cream,3.5)+path('M209 144h34M209 156h25M209 168h34','none',2.5)+path('M212 190l7 7 16-17','none',4)+circle(221,185,7,base,ink,3);}
 if(kind==='processing'){back+=path('M53 182q-19 27 30 48M191 182q13 30-17 47','none',6);front+=path('M78 225h97l-8 29H87Z','#ffd65a',4)+path('M80 234H65m108 0h15','none',5)+path('M106 211q-7-6 0-12m22 12q-7-6 0-12m22 12q-7-6 0-12','none',3);front+=path('M85 63V47c-19 0-22-26-4-31 8-23 33-19 40-6 15-15 37-6 37 7 23 2 26 29 7 32v14Z',cream,4)+path('M85 51h80','none',3);}
 if(kind==='error'){back+=path('M54 182q-21 25-4 38M190 182q20 13 28-12','none',6);front+=path('M192 131h55v82h-55Z','#ffd65a',4)+path('M202 141h35v22h-35Z',cream,2.5)+path('M213 146l11 11m-11 0 11-11','none',3)+[204,219,234].map(x=>circle(x,178,3.5,ink)+circle(x,194,3.5,ink)).join('')+path('M54 72q1-14 14-14 18 0 14 15-3 8-13 11v6','none',5)+circle(69,103,3.5,ink);}
 if(off){back+=path('M54 182q-20 21-21 2l4-28M192 182q20 26 7 38','none',6);front+=path('M36 155q4-13 12-11m-10 10-8-7','none',4)+path('M211 68q15-12 29 0m-22 9q7-5 14 0','none',3)+circle(225,87,2.8,ink)+path('M206 54l37 41','none',4);}
 const leaves=path(cooked?'M73 121q13 20 14 30M123 102q-4 16 0 34M180 134l-10 18':'M70 119q15 15 17 32M114 70q9 28 8 57M174 106q-11 16-13 39','none',3,'#4e9d32');
 const tilt=kind==='locked'?'rotate(5 127 218)':cooked?'rotate(-9 128 233)':'';
 return `<svg viewBox="0 0 280 300" aria-hidden="true" focusable="false">${ellipse(135,272,88,10,'#173a2912')}<g class="pet-body"><g transform="${tilt}">${back}${path(body,base,5)}${path('M67 214q61 28 117-1q-13 23-57 23-37 0-60-22Z','#90d95b',0,'none')}${leaves}${eyes(kind)}${front}</g></g></svg>`;
}
function scoreState(score){if(score<25)return scoreStates[0];if(score<50)return scoreStates[1];if(score<75)return scoreStates[2];if(score<100)return scoreStates[3];return scoreStates[4];}

return Object.freeze({scoreStates,runtimeStates,svg:pet,forScore:scoreState});
})();
