// Presentation only. Never calculate or replace the model's duration or score.
const GrassView = (() => {
  function answer(state) {
    const value = state.report?.answer;
    if (state.status !== 'complete' || state.report?.valid !== true || !value) return null;
    if (!Number.isInteger(value.score) || value.score < 0 || value.score > 100) return null;
    if (typeof value.estimated_desk_minutes !== 'number' || !Number.isFinite(value.estimated_desk_minutes) || value.estimated_desk_minutes < 0) return null;
    return value;
  }
  const runtime = id => GrassBro.runtimeStates.find(state => state.id === id);
  function character(state, disconnected = false) {
    if (disconnected) return runtime('offline');
    if (state.capture_error && state.status === 'collecting') return {...runtime('error'), quote:'camera needs a hand.', name:'Capture needs attention'};
    const result = answer(state);
    if (result) return GrassBro.forScore(result.score);
    switch (state.status) {
      case 'loading': return {...runtime('waiting'), quote:'one sec, brother.', name:'Loading your report'};
      case 'collecting': return runtime('collecting');
      case 'processing': return runtime('processing');
      case 'ready': return runtime('ready');
      case 'needs_review': return runtime('error');
      case 'failed': return {...runtime('error'), quote:'well, that went sideways.', name:'Processing stopped'};
      case 'complete': return {...runtime('error'), quote:"that math ain't mathing.", name:'Report unavailable'};
      default: return runtime('waiting');
    }
  }
  function key(state, pet) {
    return [state.batch_id || state.date, state.job || '', state.report?.generated_at || '', state.status, pet.id, pet.quote].join('|');
  }
  return Object.freeze({answer, character, key});
})();
