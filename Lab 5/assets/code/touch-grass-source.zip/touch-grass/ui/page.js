const $ = id => document.getElementById(id);
let selectedBatch = new URLSearchParams(location.search).get('day');
let lastState = null;
let photoKey = '';
let timelineKey = '';
let petKey = '';
let petLines = [];
let lineIndex = 0;
let reactionTimer;
let refreshTimer;
let pendingRequest;
let requestNumber = 0;
const time = value => new Date(value).toLocaleTimeString('en-US', {timeZone:'America/New_York',hour:'numeric',minute:'2-digit'});
const date = value => new Date(value+'T12:00:00-05:00').toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
const stateLabel = value => ({present:'person detected',absent:'no person detected',unknown:'unknown'})[value] || 'unknown';

function paintPet(state, disconnected = false) {
  const pet = GrassView.character(state, disconnected);
  const key = GrassView.key(state, pet) + (disconnected ? '|offline' : '');
  if (key === petKey) return;
  petKey = key;
  clearTimeout(reactionTimer);
  $('pet-button').classList.remove('react');
  $('pet-art').innerHTML = GrassBro.svg(pet.id);
  $('report').dataset.mood = pet.id;
  $('pet-state').textContent = pet.name;
  petLines = [pet.quote, ...(pet.extra || [])];
  lineIndex = 0;
  $('pet-quote').textContent = petLines[0];
  $('pet-button').disabled = petLines.length === 1;
  $('pet-button').setAttribute('aria-label', 'Make '+pet.name+' Grass bro react');
  $('pet-hint').textContent = petLines.length > 1 ? 'Tap Grass bro. He has more to say.' : 'Grass bro is keeping an eye on things.';
  $('live-notice').textContent = pet.name+'. '+pet.quote;
  if (petLines.length > 1) {
    $('pet-button').classList.add('react');
    reactionTimer=setTimeout(()=>$('pet-button').classList.remove('react'),800);
  }
}

function batchLabel(batch) {
  const stamp = /^express-\d{8}-(\d{2})(\d{2})\d{2}-\d{6}$/.exec(batch.id);
  return date(batch.date) + (batch.kind === 'express_demo' ? ' · Demo'+(stamp?' '+stamp[1]+':'+stamp[2]:'') : '');
}

function renderTimeline(state, batch) {
  const readings = state.sampling_slots?.length ? state.sampling_slots : (state.detections || []);
  const key = batch+':'+JSON.stringify(readings.map(r=>[r.t,r.state,r.simulated_at]));
  if (key === timelineKey) return;
  timelineKey = key;
  $('timeline').replaceChildren();
  $('sample-detail').textContent = 'Select a sample to see its time and detection.';
  if (!readings.length) {
    const note = document.createElement('p');
    note.textContent = 'The receipts arrive after processing.';
    $('timeline').append(note);
    return;
  }
  readings.forEach(reading => {
    const tick = document.createElement('button');
    tick.type = 'button';
    tick.className = 'tick '+(['present','absent'].includes(reading.state)?reading.state:'unknown');
    const detail = time(reading.t)+' actual'+(reading.simulated_at ? ' · '+time(reading.simulated_at)+' simulated' : '')+': '+stateLabel(reading.state)+'.';
    tick.setAttribute('aria-label', detail);
    tick.title = detail;
    tick.addEventListener('click', () => {
      $('timeline').querySelector('.selected')?.classList.remove('selected');
      tick.classList.add('selected');
      $('sample-detail').textContent = detail;
    });
    $('timeline').append(tick);
  });
}

function renderPhotos(state, batch) {
  const samples = (state.samples || []).filter(sample=>sample.file).slice(-60);
  const key = batch+':'+samples.map(sample=>sample.file).join('|');
  if (key === photoKey) return;
  photoKey = key;
  $('photos').replaceChildren();
  for (const sample of samples) {
    const figure=document.createElement('figure'), img=document.createElement('img'), caption=document.createElement('figcaption');
    img.src='/media/'+encodeURIComponent(batch)+'/'+encodeURIComponent(sample.file.split('/').pop());
    img.loading='lazy';
    img.alt='Desk sample at '+time(sample.captured_at);
    caption.textContent=time(sample.captured_at)+' actual';
    figure.append(img,caption);$('photos').append(figure);
  }
}

function render(state) {
  lastState = state;
  $('report').setAttribute('aria-busy','false');
  const express = state.kind === 'express_demo';
  const setup = state.kind === 'setup_test';
  const batch = state.batch_id || state.date;
  const answer = GrassView.answer(state);
  $('connection').textContent = 'Pi connected';
  $('connection').classList.remove('offline');
  const options = [...(state.batches || (state.days || []).map(day=>({id:day,date:day,kind:'daytime'})))];
  if (!options.some(item=>item.id===batch)) options.unshift({id:batch,date:state.date,kind:state.kind});
  const optionKey=options.map(item=>item.id+':'+batchLabel(item)).join('|');
  if ($('day').dataset.options !== optionKey) {
    $('day').replaceChildren(...options.map(item=>new Option(batchLabel(item),item.id)));
    $('day').dataset.options=optionKey;
  }
  $('day').value=batch;
  $('day-label').textContent=date(state.date)+' in New York';
  $('test-tag').hidden=!express&&!setup;
  $('test-tag').textContent=express?'Simulated day · 15-minute capture':'Setup test · not a full day';
  $('mode-note').textContent=express?'Fifteen real minutes, mapped to a simulated 08:00–20:00 day. This is not a full-day measurement.':setup?'A short setup test. These photos do not represent a full day.':'A few photos during the day. A little judgment when the report is ready.';
  $('score-label').textContent=express?'Simulated Touch grass score':'Touch grass score';
  $('report-title').textContent=express?'Simulated time at the desk':'Time at the desk';
  $('score').textContent=answer?String(answer.score):'—';
  $('desk-time').textContent=answer?answer.estimated_desk_minutes.toLocaleString('en-US',{maximumFractionDigits:1})+' min':'Not estimated yet';
  $('result-note').textContent=answer?'Qwen’s estimate from sampled photos. Presence does not prove computer use.':'The score appears after a report passes validation.';
  const band=answer?GrassBro.scoreStates.findIndex(item=>item.id===GrassBro.forScore(answer.score).id):-1;
  [...$('score-bands').children].forEach((element,index)=>element.classList.toggle('active',index<=band));
  paintPet(state);

  const remaining=Math.max(0,state.remaining_seconds||0);
  const countdown=String(Math.floor(remaining/60)).padStart(2,'0')+':'+String(remaining%60).padStart(2,'0');
  const next=state.next_start?date(state.next_start.slice(0,10)):date(state.first_day);
  const statuses={
    armed:['Express demo is ready','Press either Mini PiTFT button to start 15 minutes of capture. It has not started yet.'],
    scheduled:['Waiting for the next day','Collection starts '+next+' at 8:00 AM. Press a Pi button when you finish for the day.'],
    collecting:express?['Gathering the receipts',countdown+' remaining. One photo every 30 seconds. Capture stops after 15 minutes.']:['Gathering the receipts','One photo every five minutes. Press a Mini PiTFT button to stop capture and start analysis.'],
    ready:['The receipts are in',express?'Capture finished. Press either Mini PiTFT button to start analysis.':'The short setup batch is ready. Press either Mini PiTFT button to analyze it.'],
    processing:['Preparing your report',state.progress?.stage==='reasoning'?'Qwen is estimating desk time and the score.':('Reading saved photos'+(state.progress?.total?': '+state.progress.done+' of '+state.progress.total:'')+'.')],
    complete:[express?'Your simulated report is ready':'Your report is ready','Sampling can miss people. Check the receipts if the result looks off.'],
    needs_review:['The report needs a second look',state.error||'The model response did not pass validation. The original answer is saved below. Press the Pi button to retry.'],
    failed:['Processing stopped',state.error||'Check the device, then press the Mini PiTFT button to retry.'],
    cancelled:['Demo cancelled','Saved observations are kept. Daily collection is restored.'],
    expired:['Demo window ended','Saved demo observations are kept. Daily collection has resumed.']
  };
  let [title,detail]=statuses[state.status]||['Standing by','The device is getting ready.'];
  if(state.status==='complete'&&!answer){title='The report needs a second look';detail='A valid score is unavailable. The original model response is saved below.';}
  $('status-title').textContent=title;
  $('status-detail').textContent=detail+(state.capture_error?' '+state.capture_error:'');
  const error=!!state.capture_error||['failed','needs_review'].includes(state.status)||(state.status==='complete'&&!answer);
  $('status-detail').classList.toggle('error',error);$('status-dot').classList.toggle('error',error);
  $('capture-count').textContent=(state.sample_count||0)+' photos saved';
  $('progress').hidden=state.status!=='processing'&&!(express&&state.status==='collecting');
  if(express&&state.status==='collecting'){
    $('progress').max=state.duration_seconds||900;$('progress').value=Math.max(0,$('progress').max-remaining);
    $('progress').setAttribute('aria-label','Capture progress');
  } else if(state.progress?.stage==='detecting'){
    $('progress').max=state.progress.total||1;$('progress').value=state.progress.done||0;
    $('progress').setAttribute('aria-label','Photo analysis progress');
  } else {$('progress').removeAttribute('value');$('progress').setAttribute('aria-label','Preparing the report');}
  $('summary').textContent=answer?.summary||'No validated report yet.';
  $('uncertainty').textContent=answer?.uncertainty||(express?'A compressed demonstration, not a full day of measurement.':'Sampling gives an estimate, not a continuous record.');
  $('raw').textContent=state.report?.raw||'No response yet.';
  $('sample-count').textContent=(state.sample_count||0)+' photos'+(state.missing_count?' · '+state.missing_count+' failed captures':'');
  renderTimeline(state,batch);renderPhotos(state,batch);
  $('capture-note').textContent=express?'Each real 30-second slot represents 24 simulated minutes.'+(state.collection_started_at?' Real capture: '+time(state.collection_started_at)+' to '+time(state.window_end)+'.':' Capture has not started.')+' Missing samples remain unknown.':setup?'Setup photos were taken seconds apart. This is not a full-day measurement.':'One photo every five minutes, starting at 8:00 AM.'+(state.collection_started_at?' This batch started at '+time(state.collection_started_at)+'.':'');
  $('updated').textContent='Updated '+time(state.local_time)+' · New York';
}

function renderDisconnected() {
  $('report').setAttribute('aria-busy','false');
  paintPet(lastState||{status:'scheduled',date:'unknown'},true);
  $('connection').textContent='Pi disconnected';$('connection').classList.add('offline');
  $('score').textContent='—';$('desk-time').textContent='Unavailable offline';
  [...$('score-bands').children].forEach(element=>element.classList.remove('active'));
  $('result-note').textContent='Reconnect to load the report. Any receipts below are from the last successful update.';
  $('status-title').textContent='Cannot reach your Pi';
  $('status-detail').textContent='Check that the Pi is on and this device is on the same network. The page reconnects automatically.';
  $('status-detail').classList.add('error');$('status-dot').classList.add('error');$('progress').hidden=true;
  $('capture-count').textContent='Offline';
}

function renderLoading() {
  lastState=null;
  paintPet({date:selectedBatch,status:'loading'});
  $('report').setAttribute('aria-busy','true');
  $('day-label').textContent='Loading the selected day…';
  $('test-tag').hidden=true;
  $('mode-note').textContent='Retrieving saved observations from your Pi.';
  $('score-label').textContent='Touch grass score';
  $('report-title').textContent='Time at the desk';
  $('score').textContent='—';$('desk-time').textContent='Loading report';
  $('result-note').textContent='The selected report will appear here.';
  [...$('score-bands').children].forEach(element=>element.classList.remove('active'));
  $('status-title').textContent='Loading the selected report';
  $('status-detail').textContent='Saved reports keep their original observations and model answers.';
  $('status-detail').classList.remove('error');$('status-dot').classList.remove('error');
  $('progress').hidden=true;$('capture-count').textContent='';
  photoKey=timelineKey='';$('timeline').replaceChildren();$('photos').replaceChildren();
  $('sample-count').textContent='';$('sample-detail').textContent='';$('capture-note').textContent='';
  $('summary').textContent='Loading report…';$('uncertainty').textContent='';$('raw').textContent='Loading report…';
  $('updated').textContent='Loading saved data…';
}

async function refresh() {
  clearTimeout(refreshTimer);
  pendingRequest?.abort();
  const request=++requestNumber, batch=selectedBatch, controller=new AbortController();
  pendingRequest=controller;
  const timeout=setTimeout(()=>controller.abort(),10000);
  try {
    const response=await fetch('/api/state'+(batch?'?day='+encodeURIComponent(batch):''),{cache:'no-store',signal:controller.signal});
    if(!response.ok)throw new Error('Service unavailable');
    const state=await response.json();
    if(request===requestNumber&&batch===selectedBatch)render(state);
  } catch(error) {if(request===requestNumber)renderDisconnected();}
  finally {
    clearTimeout(timeout);
    if(request===requestNumber){pendingRequest=null;refreshTimer=setTimeout(refresh,3000);}
  }
}

$('pet-button').addEventListener('click',()=>{
  if(petLines.length<2)return;
  lineIndex=(lineIndex+1)%petLines.length;
  $('pet-quote').textContent=petLines[lineIndex];$('live-notice').textContent=petLines[lineIndex];
  clearTimeout(reactionTimer);$('pet-button').classList.remove('react');void $('pet-button').offsetWidth;
  $('pet-button').classList.add('react');reactionTimer=setTimeout(()=>$('pet-button').classList.remove('react'),800);
});
$('day').addEventListener('change',()=>{
  selectedBatch=$('day').value;
  const url=new URL(location.href);url.searchParams.set('day',selectedBatch);history.replaceState(null,'',url);
  renderLoading();
  refresh();
});
$('pet-art').innerHTML=GrassBro.svg('waiting');
refresh();
