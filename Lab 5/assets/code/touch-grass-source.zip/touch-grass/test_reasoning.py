import copy
import json
from pathlib import Path
import tempfile
import unittest

from reasoning import make_evidence, make_prompt, request_report, validate_reasoned_report


def evidence(present=23, absent=7, unknown=0, seconds=1440, simulated=True):
    rows = [{'state': name} for name, n in [('present', present), ('absent', absent), ('unknown', unknown)] for _ in range(n)]
    return make_evidence(rows, seconds, simulated)


def answer(e, minutes=552, score=100):
    return {**{k: e[k] for k in ('present_samples', 'absent_samples', 'unknown_samples', 'is_simulation')},
            'estimated_desk_minutes': minutes, 'score': score,
            'summary': 'Simulated day: a model-generated result.',
            'uncertainty': f"Simulation: unknown slots: {e['unknown_samples']}; possible missed detections; presence does not prove computer use."}


class ReportChecks(unittest.TestCase):
    def test_structured_counts_do_not_include_precomputed_answers(self):
        e=evidence(3,2,1)
        self.assertEqual((e['present_samples'],e['absent_samples'],e['unknown_samples']), (3,2,1))
        self.assertNotIn('estimated_desk_minutes',e)
        self.assertNotIn('score',e)
        self.assertNotIn('552',make_prompt(evidence()))
        for interval in (0,-1,float('inf'),True):
            with self.assertRaises(ValueError): evidence(seconds=interval)

    def test_valid_answer_is_returned_unchanged(self):
        value=answer(evidence()); saved=copy.deepcopy(value)
        self.assertIs(validate_reasoned_report(value,evidence()),value)
        self.assertEqual(value,saved)

    def test_rejects_previous_failures_even_if_numbers_are_in_range(self):
        for value,e in [(answer(evidence(),672,100),evidence()),
                        (answer(evidence(),552,140),evidence()),
                        (answer(evidence(1,29),24,50),evidence(1,29))]:
            original=copy.deepcopy(value)
            with self.assertRaises(ValueError): validate_reasoned_report(value,e)
            self.assertEqual(value,original)

    def test_rejects_invented_counts_and_wrong_simulation_flags(self):
        for key,value in [('present_samples',28),('unknown_samples',1),('present_samples',True),('is_simulation',False)]:
            with self.assertRaises(ValueError): validate_reasoned_report(dict(answer(evidence()),**{key:value}),evidence())

    def test_requires_simulation_and_unknown_disclosure(self):
        for key,value in [('summary','A real day at work'),('uncertainty','Simulation: unknown slots: 3')]:
            with self.assertRaises(ValueError): validate_reasoned_report(dict(answer(evidence()),**{key:value}),evidence())

    def test_zero_unknown_only_fractional_and_rounding_boundary(self):
        for e,minutes,score in [(evidence(0,2,1),0,0),(evidence(0,0,3),0,0),
                                (evidence(1,0,1,6),0.1,0),(evidence(1,0,0,144),2.4,1),
                                (evidence(1,29),24,5),(evidence(20,10),480,100)]:
            self.assertEqual(validate_reasoned_report(answer(e,minutes,score),e)['score'],score)

    def test_retries_keep_failed_raw_answer_and_never_send_corrected_numbers(self):
        e=evidence(); bad=answer(e,672,100); good=answer(e)
        replies=iter([bad,good]); requests=[]
        def generate(request):
            requests.append(request)
            return {'response':json.dumps(next(replies))}
        with tempfile.TemporaryDirectory() as tmp:
            report=request_report(e,'test-model',tmp,generate)
            self.assertTrue(report['valid']); self.assertEqual(len(report['attempts']),2)
            self.assertEqual(report['answer'],good)
            self.assertEqual(json.loads((Path(tmp)/'attempt-1/raw-response.txt').read_text()),bad)
            self.assertNotIn('552',requests[1]['prompt'])
            self.assertEqual(json.loads(report['raw']),good)

    def test_exhausted_retries_have_no_fallback_answer(self):
        with tempfile.TemporaryDirectory() as tmp:
            report=request_report(evidence(),'test-model',tmp,lambda request:{'response':json.dumps(answer(evidence(),672,100))})
            self.assertFalse(report['valid']);self.assertNotIn('answer',report)
            self.assertEqual(len(report['attempts']),3)
            self.assertEqual(json.loads(report['raw'])['estimated_desk_minutes'],672)

    def test_malformed_json_is_preserved_and_retried(self):
        with tempfile.TemporaryDirectory() as tmp:
            report=request_report(evidence(),'test-model',tmp,lambda request:{'response':'not json'},max_attempts=1)
            self.assertFalse(report['valid'])
            self.assertEqual((Path(tmp)/'raw-response.txt').read_text(),'not json')


if __name__ == '__main__':
    unittest.main()
