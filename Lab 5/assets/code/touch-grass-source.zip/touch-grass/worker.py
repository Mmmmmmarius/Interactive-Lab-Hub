"""Camera capture and isolated YOLO/Qwen work, using the existing Lab 5 venv."""
import argparse
from datetime import datetime
import json
from pathlib import Path
import time

from core import ZONE, make_sampling_slots, read_json, write_json
from reasoning import make_evidence, request_report


def capture(output):
    import cv2
    camera = cv2.VideoCapture(0, cv2.CAP_V4L2)
    try:
        camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        if not camera.isOpened():
            raise RuntimeError('Camera unavailable. Close other camera demos and check its connection.')
        ok, frame = False, None
        for _ in range(8):
            ok, frame = camera.read()
            time.sleep(0.07)
        if not ok or frame is None:
            raise RuntimeError('The camera did not return an image.')
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        if not cv2.imwrite(str(output), frame, [cv2.IMWRITE_JPEG_QUALITY, 85]):
            raise RuntimeError('Could not save the camera image.')
        print(json.dumps({'captured_at': datetime.now(ZONE).isoformat()}), flush=True)
    finally:
        camera.release()


def analyze(manifest_path, config_path, output_dir):
    import requests
    from ultralytics import YOLO
    config = read_json(config_path)
    manifest = read_json(manifest_path)
    base = Path(manifest_path).parent
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    model = YOLO(config['model_path'])
    readings = []
    for index, sample in enumerate(manifest['samples']):
        result = {'t': sample['captured_at'], 'file': sample.get('file'), 'state': 'unknown'}
        if sample.get('file'):
            try:
                prediction = model.predict(str(base / sample['file']), imgsz=320, conf=config['confidence'],
                                           classes=[0], verbose=False)[0]
                boxes = []
                for box in prediction.boxes:
                    boxes.append({'xyxy': box.xyxy[0].tolist(), 'confidence': float(box.conf[0])})
                result.update(state='present' if boxes else 'absent', boxes=boxes)
            except Exception as exc:
                result['error'] = str(exc)
        else:
            result['error'] = sample.get('error', 'Missing photo')
        readings.append(result)
        print(json.dumps({'stage': 'detecting', 'done': index + 1, 'total': len(manifest['samples'])}), flush=True)
    write_json(out / 'detections.json', readings)
    with (out / 'night_log.jsonl').open('w', encoding='utf-8') as log:
        for reading in readings:
            log.write(json.dumps(reading) + '\n')

    start = datetime.fromisoformat(manifest['window_start'])
    end = datetime.fromisoformat(manifest['window_end'])
    simulation = manifest.get('simulation')
    interval = simulation['interval_seconds'] if simulation else manifest['interval_seconds']
    sampling_slots = make_sampling_slots(manifest, readings)
    lines = []
    for reading in sampling_slots:
        state = {'present': 'P', 'absent': 'A', 'unknown': 'U'}.get(reading['state'], 'U')
        stamp = reading['t']
        if simulation:
            stamp += ' [simulated ' + reading['simulated_at'] + ']'
        lines.append(stamp + '=' + state)
    log_text = '\n'.join(lines)
    (out / 'model-input.txt').write_text(log_text + '\n', encoding='utf-8')
    write_json(out / 'sampling-slots.json', sampling_slots)
    evidence = make_evidence(sampling_slots, interval, simulated=bool(simulation))

    def generate(request):
        response = requests.post('http://127.0.0.1:11434/api/generate', json=request, timeout=180)
        response.raise_for_status()
        return response.json()

    def progress(attempt):
        print(json.dumps({'stage': 'reasoning', 'done': len(readings), 'total': len(readings),
                          'attempt': attempt, 'max_attempts': 3}), flush=True)

    report = request_report(evidence, config['llm'], out, generate, progress=progress)
    report.update(generated_at=datetime.now(ZONE).isoformat(), kind=manifest['kind'],
                  score_scale='Qwen estimates the score. 0 desk hours = 0; 8 or more hours = 100.')
    if simulation:
        report['simulation'] = simulation
        report['actual_capture_window'] = {'start': manifest['window_start'], 'end': manifest['window_end']}
    write_json(out / 'report.json', report)
    print(json.dumps({'stage': 'finished', 'valid': report['valid']}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='action', required=True)
    camera = sub.add_parser('capture')
    camera.add_argument('--output', required=True)
    analysis = sub.add_parser('analyze')
    analysis.add_argument('--manifest', required=True)
    analysis.add_argument('--config', required=True)
    analysis.add_argument('--output', required=True)
    args = parser.parse_args()
    if args.action == 'capture':
        capture(args.output)
    else:
        analyze(args.manifest, args.config, args.output)
