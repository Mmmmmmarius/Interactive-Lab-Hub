"""Scheduling and output validation. Desk time and score are computed by Qwen."""
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo
import json
import math
from pathlib import Path

ZONE = ZoneInfo('America/New_York')


def now():
    return datetime.now(ZONE)


def day_key(moment):
    local = moment.astimezone(ZONE)
    return (local.date() if local.hour >= 8 else local.date() - timedelta(days=1)).isoformat()


def day_start(day):
    return datetime.combine(datetime.fromisoformat(day).date(), time(8), ZONE)


def next_start(moment, first_day):
    start = day_start(first_day)
    if moment < start:
        return start
    local = moment.astimezone(ZONE)
    candidate = day_start(local.date().isoformat())
    return candidate if moment < candidate else day_start((local.date() + timedelta(days=1)).isoformat())


def slot(moment, start, interval):
    return math.floor((moment.timestamp() - start.timestamp()) / interval)


def read_json(path, default=None):
    path = Path(path)
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else default


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temp.replace(path)


def make_sampling_slots(manifest, readings):
    """Align real observations to sampling slots, optionally labeling a simulated clock.

    This maps timestamps only. Qwen still counts presence and calculates desk time and score.
    """
    start = datetime.fromisoformat(manifest['window_start'])
    end = datetime.fromisoformat(manifest['window_end'])
    interval = manifest['interval_seconds']
    observed = {slot(datetime.fromisoformat(r['t']), start, interval): r for r in readings}
    simulation = manifest.get('simulation')
    simulated_start = datetime.fromisoformat(simulation['start']) if simulation else None
    records = []
    cursor, index = start, 0
    while cursor < end:
        reading = observed.get(index)
        record = {'t': cursor.isoformat(), 'state': reading['state'] if reading else 'unknown'}
        if simulation:
            record['simulated_at'] = datetime.fromtimestamp(simulated_start.timestamp() + index * simulation['interval_seconds'], ZONE).isoformat()
        records.append(record)
        index += 1
        cursor = datetime.fromtimestamp(start.timestamp() + index * interval, ZONE)
    return records


def validate_report(value, max_minutes=None):
    """Validate only. Do not recalculate, clamp or substitute the model's numbers."""
    if not isinstance(value, dict):
        raise ValueError('The model did not return a report object.')
    score = value.get('score')
    minutes = value.get('estimated_desk_minutes')
    if type(score) is not int or not 0 <= score <= 100:
        raise ValueError('The model score must be an integer from 0 to 100.')
    if type(minutes) not in (int, float) or not math.isfinite(minutes) or not 0 <= minutes <= 1500:
        raise ValueError('The model desk-time estimate is outside the supported daily range.')
    if max_minutes is not None and minutes > max_minutes + 1e-9:
        raise ValueError('The model estimated more desk time than this recording could contain. Review the original answer.')
    for key in ('summary', 'uncertainty'):
        if not isinstance(value.get(key), str) or not value[key].strip():
            raise ValueError('The model did not provide ' + key + '.')
    return value


class PressEdge:
    """One event per press, including a long press or both buttons together."""
    def __init__(self, debounce=0.08):
        self.debounce = debounce
        self.candidate = False
        self.since = 0.0
        self.stable = False

    def update(self, pressed, clock):
        if pressed != self.candidate:
            self.candidate, self.since = pressed, clock
        if self.candidate != self.stable and clock - self.since >= self.debounce:
            self.stable = self.candidate
            return self.stable
        return False
