import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from datetime import datetime, timedelta

from core import ZONE, PressEdge, day_key, day_start, next_start, slot, validate_report, write_json, read_json, make_sampling_slots
from app import Controller


class ScheduleTests(unittest.TestCase):
    def test_eight_and_midnight(self):
        for text, expected in [('2026-11-02T07:59:59','2026-11-01'),('2026-11-02T08:00:00','2026-11-02'),('2026-11-03T00:30:00','2026-11-02')]:
            self.assertEqual(day_key(datetime.fromisoformat(text).replace(tzinfo=ZONE)),expected)

    def test_calendar_start_across_dst(self):
        moment=datetime(2026,10,31,23,30,tzinfo=ZONE)
        next_day=next_start(moment,'2026-10-31')
        self.assertEqual(next_day.hour,8)
        self.assertEqual(next_day.utcoffset().total_seconds(),-5*3600)

    def test_no_capture_before_activation_and_no_catchup(self):
        with tempfile.TemporaryDirectory() as tmp:
            conf=Path(tmp)/'config.json'
            write_json(conf,{'store':str(Path(tmp)/'store'),'first_day':'2026-11-02'})
            c=Controller(conf)
            captures=[]
            c.take_sample=lambda meta:captures.append(meta['last_slot'])
            c.tick(datetime(2026,11,2,7,59,tzinfo=ZONE))
            self.assertEqual(captures,[])
            c.tick(datetime(2026,11,2,9,11,tzinfo=ZONE))
            c.tick(datetime(2026,11,2,9,12,tzinfo=ZONE))
            self.assertEqual(captures,[14])
            meta=c.load('2026-11-02');meta['status']='complete';c.save(meta)
            c.tick(datetime(2026,11,2,9,15,tzinfo=ZONE))
            self.assertEqual(captures,[14])

    def test_debounce_hold_and_release(self):
        button=PressEdge()
        states=[(False,0),(True,.01),(False,.03),(True,.04),(True,.14),(True,4),(False,4.01),(False,4.11),(True,5),(True,5.1)]
        self.assertEqual(sum(button.update(p,t) for p,t in states),2)

    def test_model_output_is_validated_not_corrected(self):
        good={'score':77,'estimated_desk_minutes':123,'summary':'Model output','uncertainty':'Sampling gaps'}
        self.assertIs(validate_report(good),good)
        for score in [-1,101,True,20.5]:
            with self.assertRaises(ValueError):validate_report(dict(good,score=score))
        with self.assertRaises(ValueError):validate_report(dict(good,estimated_desk_minutes=float('nan')))
        with self.assertRaises(ValueError):validate_report(good,max_minutes=1)
        short=dict(good,score=0,estimated_desk_minutes=0.1)
        self.assertIs(validate_report(short,max_minutes=0.2),short)

    def test_busy_and_empty_buttons_do_not_start_jobs(self):
        with tempfile.TemporaryDirectory() as tmp:
            conf=Path(tmp)/'config.json';write_json(conf,{'store':str(Path(tmp)/'store'),'first_day':'2099-01-01'})
            c=Controller(conf)
            self.assertIn('No photos',c.process_button()['message'])
            c.busy=True
            self.assertIn('Already processing',c.process_button()['message'])
            self.assertFalse((Path(tmp)/'store/days').exists())

    def test_only_setup_batches_can_repeat_after_completion(self):
        with tempfile.TemporaryDirectory() as tmp, patch('app.now',return_value=datetime(2026,11,1,21,tzinfo=ZONE)), patch('app.threading.Thread') as thread:
            conf=Path(tmp)/'config.json';write_json(conf,{'store':str(Path(tmp)/'store'),'first_day':'2026-11-02'})
            c=Controller(conf)
            meta=c.new_day('2026-11-01','setup_test')
            meta.update(status='complete',samples=[{'file':'photos/test.jpg'}])
            c.save(meta)
            self.assertIn('Processing started',c.process_button()['message'])
            self.assertEqual(c.last_button['source'],'software-check')
            thread.return_value.start.assert_called_once()
            c.busy=False
            meta.update(kind='daytime',status='complete');c.save(meta)
            self.assertIn('batch is complete',c.process_button(source='physical-button')['message'])
            self.assertEqual(c.last_button['source'],'physical-button')
            thread.return_value.start.assert_called_once()


class ExpressDemoTests(unittest.TestCase):
    def test_two_presses_fifteen_minutes_and_daily_recovery(self):
        moment=datetime(2026,11,1,22,tzinfo=ZONE)
        clock=[moment]
        with tempfile.TemporaryDirectory() as tmp, patch('app.now',side_effect=lambda:clock[0]), patch('app.threading.Thread') as thread:
            conf=Path(tmp)/'config.json';write_json(conf,{'store':str(Path(tmp)/'store'),'first_day':'2026-11-02'})
            c=Controller(conf)
            original=c.new_day('2026-11-01','setup_test');original['status']='complete';c.save(original)
            original_bytes=(c.path('2026-11-01')/'day.json').read_bytes()
            key=c.arm_demo()['batch_id']
            self.assertEqual(c.state()['status'],'armed')
            self.assertEqual(c.state()['sample_count'],0)
            self.assertEqual(c.path(key).parent.name,'demos')
            self.assertEqual(c.arm_demo()['batch_id'],key)
            def capture(meta):
                meta['samples'].append({'captured_at':clock[0].isoformat(),'file':'photos/test.jpg'})
                c.save(meta)
            c.take_sample=capture
            self.assertIn('capture started',c.process_button('physical-button')['message'])
            for index in range(30):
                clock[0]=moment+timedelta(seconds=index*30)
                c.tick(clock[0])
                c.tick(clock[0])
            self.assertEqual(c.state()['sample_count'],30)
            self.assertIn('Still capturing',c.process_button('physical-button')['message'])
            thread.assert_not_called()
            clock[0]=moment+timedelta(seconds=900)
            c.tick(clock[0]);c.tick(clock[0]+timedelta(seconds=30))
            self.assertEqual(c.state()['status'],'ready')
            self.assertEqual(c.state()['sample_count'],30)
            self.assertIn('Processing started',c.process_button('physical-button')['message'])
            thread.return_value.start.assert_called_once()
            self.assertEqual(c.last_button['batch_id'],key)
            self.assertIn('Already processing',c.process_button()['message'])
            c.busy=False
            done=c.load(key);done['status']='complete';c.save(done)
            clock[0]=datetime(2026,11,2,8,tzinfo=ZONE)
            c.tick(clock[0])
            self.assertEqual(c.state()['kind'],'daytime')
            self.assertEqual(c.state()['sample_count'],1)
            self.assertEqual((c.path('2026-11-01')/'day.json').read_bytes(),original_bytes)

    def test_restart_preserves_timer_and_does_not_backfill(self):
        moment=datetime(2026,11,1,22,tzinfo=ZONE)
        with tempfile.TemporaryDirectory() as tmp, patch('app.now',return_value=moment):
            conf=Path(tmp)/'config.json';write_json(conf,{'store':str(Path(tmp)/'store'),'first_day':'2026-11-02'})
            c=Controller(conf);key=c.arm_demo()['batch_id'];c.process_button()
            saved_end=c.load(key)['window_end']
            restored=Controller(conf);captures=[]
            restored.take_sample=lambda meta:captures.append(meta['last_slot'])
            restored.tick(moment+timedelta(seconds=305))
            self.assertEqual(captures,[10])
            self.assertEqual(restored.load(key)['window_end'],saved_end)
            restored.return_to_daily()
            self.assertEqual(restored.load(key)['status'],'cancelled')
            self.assertIsNone(restored.active_demo())
            with self.assertRaises(ValueError):restored.path('express-../../control-token')

    def test_real_timestamps_and_simulated_clock_stay_separate(self):
        actual=datetime(2026,11,1,22,tzinfo=ZONE)
        simulated=actual.replace(hour=8)
        manifest={'window_start':actual.isoformat(),'window_end':(actual+timedelta(minutes=15)).isoformat(),
                  'interval_seconds':30,'simulation':{'start':simulated.isoformat(),'interval_seconds':1440}}
        readings=[{'t':actual.isoformat(),'state':'present'},
                  {'t':(actual+timedelta(seconds=30)).isoformat(),'state':'absent'}]
        records=make_sampling_slots(manifest,readings)
        self.assertEqual(len(records),30)
        self.assertEqual([r['state'] for r in records[:3]],['present','absent','unknown'])
        self.assertEqual(records[0]['t'],actual.isoformat())
        self.assertEqual(records[0]['simulated_at'],simulated.isoformat())
        self.assertEqual(records[-1]['simulated_at'],simulated.replace(hour=19,minute=36).isoformat())
if __name__=='__main__':unittest.main()
