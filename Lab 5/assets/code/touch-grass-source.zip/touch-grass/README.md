# Touch grass score: source snapshot

This archive contains the custom Lab 5 implementation and the deployed Grass bro UI. It is a source snapshot for review and reproduction. The canonical working source remains in Study HQ/Projects/INFO5345/Lab5/touch_grass/.

## What runs where

- app.py schedules daytime capture, handles the physical-button queue and serves the LAN report.
- worker.py saves webcam photos and runs YOLO followed by Qwen.
- reasoning.py supplies structured observations and validates Qwen's answer. It never replaces Qwen's time or score with a calculated fallback.
- hardware.py controls the existing Mini PiTFT display and its buttons.
- control.py provides local operator commands. The control token is read locally, never embedded in this archive.
- ui/ contains the editable character, state selection, page and stylesheet. web/ contains the already-built files served by the Pi.
- The two service files document the deployed process setup. Their user and paths are specific to the existing Pi.

## Existing environment

The application uses the course Lab 5 Python environment with OpenCV, Ultralytics and requests, an exported YOLO26n NCNN model, and a local Ollama installation containing qwen3:0.6b. The screen service uses the existing Mini PiTFT environment with Pillow, Blinka and adafruit_rgb_display. Large model files, virtual environments, captured images, stored reports and live credentials are excluded.

To reproduce on a configured Pi, unpack the folder, copy config.example.json to config.json and replace first_day with a real YYYY-MM-DD date. Check store, model_path and both service paths against that machine. first_day is when daily collection may begin, at 08:00 America/New_York. Use a date that matches the intended experiment. The example is a template, not the Pi's live configuration.

Run the app with the Lab 5 virtual environment:

```bash
python app.py --config config.json
```

For the already configured display, hardware.py is run by touch-grass-screen.service in its separate environment. Do not start duplicate camera or GPIO owners. Quit the live YOLO window with q before beginning capture. Inspect the service files and adapt their paths before installing them; this archive does not install or start them automatically.

## Express demo and normal use

Daily mode captures every five minutes from 08:00 until a Mini PiTFT button hands the batch to analysis. The browser reads the saved report; it does not start captures.

On the Pi, with the application already running:

```bash
python control.py status
python control.py demo
```

The demo command arms an independent batch. The first physical button press starts 15 real minutes of capture at 30-second intervals. Capture stops automatically. The second physical button press starts analysis. Each real slot is mapped to 24 simulated minutes, producing a clearly labeled 08:00–20:00 simulated day. This does not establish a full-day measurement.

## UI build and checks

The built web files are included, so Node is unnecessary on the Pi. On the editing computer:

```bash
node build-ui.cjs
node test-ui.cjs
python -m unittest test_core.py test_reasoning.py
```

Build from ui/, then copy the generated web files into the Pi's existing web directory after backing it up. Static-file updates require a browser refresh, not a service restart.

## Evidence and attribution

The Lab 5 README beside this archive links the actual photos, model attempts, simulation log and UI screenshots. They are separate from this source package. Marius provided the project concept, schedule, physical interaction, experiments and approved visual direction. Codex implemented and documented the custom program using the course examples as references. Original teacher scripts are preserved separately. hardware.py retains its Adafruit example attribution and SPDX notices. manifest.json lists the exact source-file hashes in this snapshot.
